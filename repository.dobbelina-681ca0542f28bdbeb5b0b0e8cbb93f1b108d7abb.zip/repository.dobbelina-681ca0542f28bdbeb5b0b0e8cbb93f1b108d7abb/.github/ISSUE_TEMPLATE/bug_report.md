---
name: Bug report
about: Logfile Mandatory!
title: ''
labels: ''
assignees: ''

---

### Bug reports:

Please replace this line with a brief summary of your issue 

### OS environment
What OS, Device, version etc

1. Install Kodi Logfile Uploader addon from Offcial Kodi Repository under Program add-ons.
2. Enable Debug logging, (Settings - System - Logging - Enable Debug Logging)
3. Restart Kodi (Important)
4. Go into Cumination and open the site (wait for the error message)
5. Come out of cumination
6. Disable Debug logging, (Settings - System - Logging - Enable Debug Logging off)
7. launch Kodi Logfile uploader and upload your log. This will give you a url
8. provide the url from step 7 here

Any bugreports without logfile will be deleted.
