---
name: Feature or site addition request
about: Suggest an idea for this project
title: ''
labels: Request
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**If it's a site addition request, add url below**
Sites with no DMCA information will not be added
