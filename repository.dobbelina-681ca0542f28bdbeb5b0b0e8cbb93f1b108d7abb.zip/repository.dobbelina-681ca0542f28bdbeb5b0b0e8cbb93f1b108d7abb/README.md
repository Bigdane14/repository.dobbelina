# Cumination

<img src="https://user-images.githubusercontent.com/46063764/103461711-a9eb6280-4d20-11eb-983b-516b022cbbf5.png" width="300" align="right">

Cumination release

Welcome to Cumination!

Matrix and Leia compatible release

Backup favorites from UWC can be imported



---
All credit to the fantastic people at reddit who has provided the fixes, and especially jdoedev & 12asdfg12 & camilt


and Whitecream & holisticdioxide who are the original author/s of the addon.

For auto-updates, download repository.dobbelina-1.0.3.zip here https://dobbelina.github.io

**Please post in the "Issues" section if you can contribute to fix broken**

**sites/catchers, or make a pull request.**

[![GitHub Issues Open](https://github-basic-badges.herokuapp.com/issues/dobbelina/repository.dobbelina.svg)]()

[![GitHub Commits](https://github-basic-badges.herokuapp.com/commits/dobbelina/repository.dobbelina.svg)]()



